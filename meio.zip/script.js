
// Product 


//Important note: If you have downloaded the code
// but still encounter errors when running the program,
//    please watch the video at this link because
// I have shown you how to run the project properly.
// https://www.youtube.com/watch?v=okyfcpZfPAU&t=142s
let products = null;
// get datas from file json
fetch('products.json')
  .then(response => response.json())
  .then(data => {
    products = data;
    addDataToHTML();
  })

function addDataToHTML() {
  // remove datas default from HTML
  let listProductHTML = document.querySelector('.listProduct');

  // add new datas
  if (products != null) // if has data
  {
    products.forEach(product => {
      let newProduct = document.createElement('a');
      newProduct.href = '/detail.html?id=' + product.id;
      newProduct.classList.add('item');
      newProduct.innerHTML =
        `<img src="${product.image}" alt="">
              <h2>${product.name}</h2>
              <div class="price">$${product.price}</div>`;
      listProductHTML.appendChild(newProduct);

    });
  }
}






// Important note: If you have downloaded the code
// but still encounter errors when running the program,
//    please watch the video at this link because
// I have shown you how to run the project properly.





// ... (previous JavaScript code remains unchanged)


function toggleCart() {
  var cartContainer = document.getElementById("cartContainer");
  if (cartContainer.style.display === "block") {
    cartContainer.style.display = "none";
  } else {
    cartContainer.style.display = "block";
    updateCartItems();
  }
}


// Add this function to handle the "Add to Cart" button click event
function addToCart(productId) {
  var product = products.find(function(product) {
    return product.id === productId;
  });

  if (product) {
    var cartItem = document.createElement("div");
    cartItem.classList.add("cart-item");
    cartItem.innerHTML = `
      <img src="${product.image}" alt="${product.name}">
      <div class="cart-item-details">
        <h3>${product.name}</h3>
        <p>$${product.price}</p>
        <button class="remove-from-cart" onclick="removeFromCart(${product.id})">Remove</button>
      </div>
    `;
    document.getElementById("cartItems").appendChild(cartItem);
    updateCartItems();
  }
}





function updateCartItems() {
  var cartItems = document.getElementById("cartItems");
  cartItems.innerHTML = "";
  var cart = getCart();
  for (var i = 0; i < cart.length; i++) {
    var item = cart[i];
    var itemElement = document.createElement("div");
    itemElement.className = "cart-item";
    itemElement.innerHTML = item.name + " - $" + item.price.toFixed(2);
    cartItems.appendChild(itemElement);
  }

}
function addToCart(item) {
  var cart = getCart();
  cart.push(item);
  saveCart(cart);
  updateCartItems();

}
function getCart() {
  var cart = JSON.parse(localStorage.getItem("cart")) || [];
  return cart;

}

function saveCart(cart) {
  localStorage.setItem("cart", JSON.stringify(cart));
}
function clearCart() {
  localStorage.removeItem("cart");
  updateCartItems();

}
function checkout() {
  var cart = getCart();
  if (cart.length === 0) {
    alert("Your cart is empty. Please add items to proceed.");
    return;
  }
  // Perform checkout logic here (e.g., send order to server)
  alert("Thank you for your purchase!");
  clearCart();

}




// Slide banner
document.addEventListener("DOMContentLoaded", function() {
  const slider = document.querySelector(".slider");
  let slideIndex = 0;

  function showSlide() {
    slideIndex++;
    if (slideIndex >= slider.children.length) {
      slideIndex = 0;
    }

    const transformValue = `translateX(${-slideIndex * 100}%)`;
    slider.style.transform = transformValue;
  }

  setInterval(showSlide, 3000); // Change slide every 3 seconds (adjust as needed)
});






(function($) {

  // Ensure the document is ready before executing jQuery code
  $(document).ready(function() {
    // Your jQuery code here


    // Check if the containers exist before attempting to load content
    const containers = ['#content-container-welcome', '#content-container-OurSelection', '#content-container-products', '#content-container-story'];
    containers.forEach(function(container) {
      if ($(container).length > 0) {
        $.ajax({
          url: container.replace('#content-container-', '') + '.html',
          success: function(data) {
            $(container).html(data);
          }
        }).fail(function(xhr, status, error) {
          console.error('Error loading ' + container.replace('#content-container-', '') + '.html:', error);
        });
      }
    });
  });;
})(jQuery);















document.getElementById('add-to-cart').addEventListener('click', function() {
  var cartContainer = document.getElementById('cart-container');
  if (cartContainer.style.display === 'none' || cartContainer.style.display === '') {
    cartContainer.style.display = 'block';
  } else {
    cartContainer.style.display = 'none';
  }
});



document.getElementById('cart-container').addEventListener('click', function(event) {
  if (event.target.tagName === 'BUTTON') {
    event.target.parentNode.remove();
  }
});

// Your JavaScript code goes here

function toggleCart() {
  var cartContainer = document.getElementById("cartContainer");
  if (cartContainer.style.display === "block") {
    cartContainer.style.display = "none";
  } else {
    cartContainer.style.display = "block";
  }
}
function addToCart(productName, price) {
  var cartContainer = document.getElementById("cartContainer");
  var cartItem = document.createElement("div");
  cartItem.className = "cart-item";
  cartItem.innerHTML = "<span>" + productName + "</span><span>" + price + "</span><button>Remove</button>";
  cartContainer.appendChild(cartItem);


}



















// Assume you have an API endpoint to retrieve products from the backend
const apiEndpoint = '/api/products'; // Adjust the endpoint accordingly

// Function to fetch products from the backend
async function fetchProducts() {
  try {
    const response = await fetch(apiEndpoint);
    const products = await response.json();
    displayProducts(products);
  } catch (error) {
    console.error('Error fetching products:', error);
  }
}

// Function to display products on the frontend
function displayProducts(products) {
  const productContainer = document.getElementById('productContainer');

  // Clear existing content
  productContainer.innerHTML = '';

  // Loop through products and create HTML elements
  products.forEach(product => {
    const productDiv = document.createElement('div');
    productDiv.className = 'product';

    productDiv.innerHTML = `
                <img src="${product.ImageURL}" alt="${product.Name}">
                <h3>${product.Name}</h3>
                <h6>${product.Description}</h6>
                <p class="product-price">Price<span class="currency">$</span>${product.Price.toFixed(2)}</p>
                <button class="add-to-cart" onclick="addToCart(${product.ProductID})">Add to Cart <i class="fas fa-cart-plus"></i></button>
            `;

    productContainer.appendChild(productDiv);
  });
}

// Assume you have a function to add products to the cart (addToCart function)
function addToCart(productId) {
  // Implement your logic to add the product to the cart
  console.log('Product added to cart:', productId);
}

// Fetch products when the page loads
window.onload = fetchProducts;

















function handleFormSubmit(event) {
  event.preventDefault(); // Prevent the form from submitting
  // Get the user's message from the input field
  const userMessage = document.getElementById('user-message').value;
  // Clear the input field
  document.getElementById('user-message').value = '';
  // Display the user's message in the chat window
  displayMessage('user', userMessage);
  // Send the user's message to the chatbot
  sendMessageToChatbot(userMessage);

}
















// Add your JavaScript code here





// Add your JavaScript code here
// Get the button element
const button = document.getElementById("myButton");
// Add a click event listener to the button
button.addEventListener("click", function() {
  // Get the current value of the button
  const currentValue = button.innerHTML;
  // Increment the value by 1
  const newValue = parseInt(currentValue) + 1;
  // Update the button's text
  button.innerHTML = newValue;
});



// Add your JavaScript code here