/* Reset basic styles for a more consistent starting point */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Poppins', sans-serif;
}

/* Set a background color and text color for the entire page */

/* Set base font size */
html {
  height: 100%;
  width: 100%;
  font-size: 62.5%;
}

/* Set body styles */
body {
  background-color: #f5f5f5;
  font-family: sans-serif;
  font-size: 1.6rem;
  /* 16px */
  line-height: 1.5;
}

/* Header section styles */
header {
  color: #fff;
  padding: 0;
}

.navbar-brand img {
  width: 50px;
  height: 50px;
}

.brand-name {
  margin-left: 1rem;
  font-size: 1.8rem;
  /* 18px */
  color: #b7ee20;

}

.product-name {
  font-size: 18px;
  color: #555;
  margin-bottom: 10px;
}

.navbar-brand img {
  width: 100px;
  height: 100px;
  margin-right: 10px;
  border-radius: 360px;
}





.navbar-toggler {
  border-color: rgba(255, 255, 255, 0.3);
}

.navbar-collapse {
  /* Adjust collapse behavior for smaller screens */
  flex-wrap: wrap;
}

.nav-item {
  margin-left: 1rem;
}

.nav-link {
  color: #fff;
  padding: 0.5rem 1rem;
}

.nav-link:hover {
  color: #ddd;
}

.dropdown-menu {
  background-color: #222;
}

.dropdown-item {
  color: #fff;
}

.dropdown-item:hover {
  background-color: #111;
}









/* CSS for the cart container */
.cart-container {
  display: none;
  position: fixed;
  top: 0;
  right: 0;
  width: 300px;
  height: 100%;
  background-color: lavender;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
  padding: 20px;
  overflow-y: auto;
}

/* CSS for the cart items */
.cart-container ul {
  list-style: none;
  padding: 0;
}

.cart-container li {
  margin-bottom: 10px;

}

.cart-container li span {
  font-weight: bold;
}

/* CSS for the checkout button */
.cart-container button {
  display: block;
  margin-top: 20px;
  padding: 10px;
  background-color: #007bff;
  color: #fff;
  border: none;
  cursor: pointer;
}

/* ... (previous CSS styles remain unchanged) */

.close-btn {
  background-color: #333;
  color: #fff;
  border: none;
  padding: 8px 12px;
  font-size: 14px;
  cursor: pointer;
  margin-bottom: 10px;
}

.close-btn:hover {
  background-color: #555;
}

/* slide banner */
.banner-container {
  position: relative;
  width: 100%;
  height: 400px;
  overflow: hidden;
}
















#content-container-welcome,
#content-container-OurSelection,
#content-container-products,
#content-container-story,
#footer,
#content-container-contacts {
  padding: 10px;
  margin: 10px;
  border: 1px solid #ccc;
  height: auto;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

#content-container-products {
  background-color: lavender;
}

/* Optional: Add some spacing between the containers */
#content-container-welcome {
  margin-bottom: 20px;
}

#content-container-contacts {
  margin-top: 20px;
}

.search-bar {
  display: flex;
  align-items: center;
  width: 300px;
  border-radius: 4px;
  padding: 0px;
}

.search-bar input[type="text"] {
  flex: 1;
  border-radius: 20px;
  border-color: wheat;
  border-style: groove;
  margin-right: 5px;
  padding: 5px;
  font-size: 16px;
}

.search-bar button {
  background-color: gray;
  color: white;
  border: wheat;
  border-style: groove;
  padding: 5px 12px;
  cursor: pointer;
  font-size: 16px;
  border-radius: 4px;
}

.search-bar button:hover {
  background-color: #abb5ee;
}




/********** NAVBAR **********/





/* Header */


.dropdown-menu {
  display: none;
  position: absolute;
  background-color: lavender;
  min-width: 100px;
  margin-right: 20px;
  box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
  z-index: 1;
}

.dropdown-menu a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-menu a:hover {
  background-color: #f1f1f1;
}

.dropdown:hover .dropdown-menu {
  display: block;
}











.section Gallery {
  color: blue;
  flex-wrap: wrap;
  justify-content: space-between;
  align-items: center;
}

.gallery {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  grid-gap: 20px;
  padding: 20px;
  color: darkblue;
  text-align: center;
  background-color: lavender;
}

.gallery img {
  width: 100%;
  height: auto;
}

.gallery-item {
  position: relative;
  overflow: hidden;
}

.gallery-item img {
  width: 100%;
  height: auto;
  transition: transform 0.3s ease;
}

.gallery-item:hover img {
  transform: scale(1.1);
}

.gallery-item .overlay {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  opacity: 0;
  transition: opacity 0.3s ease;
}


/* Style the navigation bar */

/********** NAVBAR **********/
.navbar {
  background-color: #333;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px;
}



/********** Welcome **********/
.welcome {
  display: flex;
  height: 100rm;
  margin-top: 5px;
  margin-bottom: 5px;
}

.column {
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 100rm;
  padding: 20px;
}

.left-column {
  background-image: url('https://img.freepik.com/free-photo/female-colorful-clothing-set-racks-with-shoes-clothing-store-brand-new-modern-boutique_627829-6463.jpg?size=626&ext=jpg&uid=R109517233&ga=GA1.2.1718619702.1702951347&semt=sph');
  background-size: cover;
  background-position: center;
  height: 100rm;
}


.center-column {
  background-color: darkblue;
  color: white;
  font-size: 1.2em;
  font-style: oblique;
  line-height: 1.5;
  margin-left: 0;
  margin-right: 0;
  padding: 20px;
  text-align: center;
}

.right-column {
  background-image: url('https://img.freepik.com/free-photo/african-american-couple-looking-trendy-clothes-shopping-casual-wear-modern-boutique-cheerful-customers-checking-outfit-material-buying-stylish-merchandise-new-wardrobe-fashion-concep_482257-72435.jpg?uid=R109517233&ga=GA1.2.1718619702.1702951347');
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;

}

.center-content {
  text-align: center;
  color: white;
  font-size: 1.2em;
  font-style: oblique;
  line-height: 1.5;
  margin-left: 0;
  margin-right: 0;
  padding: 20px;


}


/*----our ::selection ---*/

.Our-selection {
  text-align: center;
  padding: 20px;
  background-image: url("https://img.freepik.com/free-photo/clothing-store-woman-assistant-adjusting-formal-female-outfit-mannequin-fashion-apparel-showroom-employee-dressing-dummy-model-office-wear-showcase-customers-new-arrival_482257-71923.jpg");
  border-radius: 5;
  color: black;
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  font-style: oblique;
  font-size: 1.2em;
  line-height: 1.5;
  margin-left: 0;
  margin-right: 0;
}

.contents {
  max-width: 800px;
  margin: 50px auto;
  padding: 20px;
  background-color: rgba(255, 255, 255, 0.2);
  border-radius: 10px;
  justify-content: center;
  color: black;
}



/*----our products ---*/
.product-container {
  display: flex;
  flex-direction: column;
  align-items: center;
}

#product-description {
  font-size: 15px;
  font-style: italic;
}

.product-gallery {
  display: flex;
  flex-wrap: wrap;
  margin: 20px;
}

.product-gallery img {
  width: 15%;
  /* Adjust the width based on your preference */
  height: auto;
  margin: 5px;
  cursor: pointer;
}

.product-price {
  color: rgb(0, 136, 0);
  font-size: 24px;
  font-style: oblique;
  vertical-align: super;
  text-align: center;
}

.currency {
  font-size: 14px;
  font-style: oblique;
  vertical-align: super;
}

.add-to-cart-button,
.buy-now-button {
  justify-content: space-between;
  gap: 10px;
  margin-top: 10px;
  flex-wrap: wrap;
}

.add-to-cart-button {
  background-color: rgb(249, 217, 76);
  border: none;
  height: 30px;
  width: 110px;
  border-radius: 15px;
  cursor: pointer;
}

.add-to-cart-button:hover {
  background-color: rgb(247, 202, 0);
}

.add-to-cart-button:active {
  opacity: 0.5;
}

.buy-now-button {
  background-color: rgb(255, 164, 28);
  border: none;
  height: 30px;
  width: 110px;
  border-radius: 15px;
  cursor: pointer;
}

.buy-now-button:hover {
  background-color: rgb(250, 137, 0);
}

.buy-now-button:active {
  opacity: 0.5;
}

/*-----our stoy ------*/

.Our-story {
  text-align: center;
  padding: 20px;
  background-image: url("https://img.freepik.com/free-photo/clothing-store-woman-assistant-adjusting-formal-female-outfit-mannequin-fashion-apparel-showroom-employee-dressing-dummy-model-office-wear-showcase-customers-new-arrival_482257-71923.jpg?uid=R109517233&ga=GA1.1.1718619702.1702951347");
  border-radius: 5;
  color: black;
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  font-style: italic;
  font-size: 1.2em;
  line-height: 1.5;
  margin-left: 0;
  margin-right: 0;
  margin-bottom: 5px;
  margin-top: 5px;
}

.content {
  max-width: 800px;
  margin: 50px auto;
  padding: 20px;
  background-color: rgba(201, 157, 195, 0.7);
  /* Background color for the text box */
  border-radius: 10px;
  text-align: left;
  justify-content: center;
}

/*-----best colour  #35465c #6c5b7b #355c7d  #c0c0c0 silver #------*/
/*-----footer------*/
footer {
  display: flex;
  justify-content: space-between;
  background-color: #35465c;
  ;


  color: #fff;
  padding: 2rem;
}

.container {
  max-width: 1140px;
  margin: 0 auto;
}

.row {
  display: flex;
  flex-wrap: wrap;
  margin: 0 -1rem;
  text-align: left;
}








footer-column {
  flex: 1;
  margin-right: 20px;
}

footer-column h3 {
  margin-bottom: 10px;
}

footer-column ul {
  list-style-type: none;
  padding: 0;
}

footer-column ul li {
  margin-bottom: 5px;
}

footer-column ul li a {
  text-decoration: none;
}

column {
  flex: 1;
  justify-content: space-between;
}

#left-column {
  margin-right: 0px;
}

#right-column {
  margin-left: 10px;
  width: 100%;
  padding-left: 20px;
}



/* contact form */

.name-group {
  display: flex;

  margin: 0;
  padding: 0;
  width: 100%;
  gap: 20px;
}

.name-group input {
  flex: 1;
}

label {
  display: block;
  margin-bottom: 8px;
}

input,
textarea {
  width: 100%;
  padding: 5px;
  margin-bottom: 16px;
  box-sizing: border-box;
  border: 1px solid #ccc;
  border-radius: 4px;
  font-size: 12px;
  font-style: italic;
}

button:hover {
  background-color: #45a049;
}

.h2 {
  color: #000;
}

.contact-form button {
  width: 100%;
  padding: 5px 10px;
  background-color: #007bff;
  color: #fff;
  border: none;
  cursor: pointer;
}



h1 {
  font-size: 2px;
}

h4 {
  color: green;
  font-size: 8px;
}

.container {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  height: auto;
}


ul {
  list-style: none;
  padding: 0;
  color: whitesmoke;
}

li {
  margin-bottom: 8px;
  color: whitesmoke;
}

select {
  width: 80%;
  padding: 10px;
  margin-bottom: 16px;
  box-sizing: border-box;
  border: 1px solid #ccc;
  border-radius: 4px;
  background-color: berlywood;
}

a {
  text-decoration: none;
  color: white;
}

a:hover {
  color: blue;
}

hr {
  border: 1px solid #333;
  margin: 20px 0;
}

p:last-child {
  margin-top: 20px;
  font-size: 14px;
  text-align: center;
}

i {
  margin-right: 5px;
}


footer-links {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10px;
}

footer-links a {
  text-decoration: none;
}

column a {
  color: #e00bc4;
  text-decoration: none;
}

column a:hover {
  color: #ffd700;
}

.footer-links a {
  color: #fff;
}









    


.social-Media {
  list-style: none;
  padding: 0;
  margin: 0;
}

.social-Media li {
  display: inline-block;
  margin: 10px;
}

.social-Media li a {
  color: inherit;
  text-decoration: none;
}

.social-Media li a:hover {
  color: #007bff;
}

.social-Media i {
  font-size: 20px;
}

.fa.fa-facebook {
  color: #3b5998;
}

.fa.fa-twitter {
  color: #1da1f2;
}

.fa.fa-instagram {
  color: #e4405f;
}

.fa.fa-youtube {
  color: #c4302b;
}

.fa.fa-pinterest {
  color: #c8232c;
}

.fa.fa-tumblr {
  color: #35465c;
}

.fa.fa-skype {
  color: #007bff;
}

.fa.fa-reddit {
  color: #ff4500;
}

.fa.fa-quora {
  color: #a72b7e;
}

.fa.fa-flickr {
  color: #ff0084;
}

.fa.fa-github {
  color: #411733;
}

.fa.fa-codepen {
  color: #239138;
}

.fa.fa-stack-overflow {
  color: #f78337;
}

.fa.fa-mycompiler {
  color: #f09300;
}






























/* cart */


.cart-container {
  display: none;
  position: fixed;
  top: 50%;
  right: 0;
  transform: translate(0, -50%);
  padding: 20px;
  background-color: #5cc3f0;
  border: 1px solid #ccc;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  z-index: 1000;
}

/* Your styles go here */

.cart-icon {
  cursor: pointer;
}

.cart-container {
  display: none;
  /* Additional styles for the cart container */
}

.cart-container.show {
  display: block;

}




/* Add more color styles for other social media platforms */













a {
  color: unset;
  text-decoration: none;
}

.product-container {
  width: 900px;
  margin: auto;
  max-width: 90vw;
  text-align: center;
  padding-top: 10px;
  padding-bottom: 10px;
}

.title {
  font-size: xx-large;
  font-style: oblique;
  padding: 20px 0;
}

.listProduct .item img {
  width: 90%;
  filter: drop-shadow(0 50px 20px #e63d9f99);
}

.listProduct {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 20px;
}

.listProduct .item {
  background-color: #EEEEE6;
  padding: 20px;
  border-radius: 20px;
}

.listProduct .item h2 {
  font-weight: 500;
  font-size: large;
}

.listProduct .item .price {
  letter-spacing: 5px;
  font-size: small;
}

/* detail page */

.detail {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 50px;
  text-align: left;
}

.detail .image img {
  width: 100%;
}

.detail .image {
  position: relative;
}

.detail .image::before {
  position: absolute;
  width: 300px;
  height: 300px;
  content: '';
  background-color: #eeeed8;
  z-index: -1;
  border-radius: 190px 100px 170px 180px;
  left: calc(50% - 150px);
  top: 50px;

}

.detail .name {
  font-size: xx-large;
  padding: 40px 0 0 0;
  margin: 0 0 10px 0;
}

.detail .price {
  letter-spacing: 5px;
  margin-bottom: 20px;
  color: rgb(0, 136, 0);
  font-size: 24px;
  font-style: oblique;
  vertical-align: super;
}

.detail .buttons {
  display: flex;
  gap: 20px;
  margin-bottom: 20px;
}

.detail .buttons button {
  background-color: #eee;
  border: none;
  padding: 15px 20px;
  border-radius: 20px;
  font-family: Poppins;
  font-size: large;
}

.detail .buttons svg {
  width: 15px;
}

.detail .buttons span {
  background-color: #555454;
  width: 30px;
  height: 30px;
  display: flex;
  justify-content: center;
  align-items: center;
  border-radius: 50%;
  margin-left: 20px;
}

.buttons button:nth-child(2) {
  background-color: #2F2F2F;
  display: flex;
  justify-content: center;
  align-items: center;
  color: #eee;
  box-shadow: 0 10px 20px #2F2F2F77;
}

.detail .buttons button:nth-child(2) svg {
  width: 20px;

}

.detail .description {
  font-weight: 300;
}




















  


.navbar-brand img {
  width: 50px;
  height: 50px;
}

.brand-name {
  margin-left: 1rem;
  font-size: 1.8rem;
  /* 18px */
}



/*Respoonsive*/
@media (max-width: 768px) {
  .container {
    flex-direction: column;
  }


  .column {
    margin-bottom: 20px;
  }

  .gallery {
    grid-template-columns: repeat(2, 1fr);
  }
}

/*phone*/
@media (max-width: 480px) {
  .container {
    flex-direction: column;
  }

  .column {
    margin-bottom: 20px;
  }
}

/* Responsive styles */
@media screen and (max-width: 48em) {
  .footer {
    flex: column;
  }

  .p {
    text-overflow: clip;
  }

  .row {
    flex-direction: column;
  }

  .footer,
  .col-md-3 .row {
    justify-content: flex-start;
    /* This assumes .footer and .col-md-3 are flex containers */
  }
}



































@media screen and (max-width: 48em) {
  nav ul {
    flex-direction: column;
  }

  .product-list {
    justify-content: flex-start;
  }
}





































































/* Our Selection and Our Story sections styles */
.Our-selection,
.Our-story {
  padding: 2rem;
  text-align: center;
}

.Our-selection p,
.Our-story p {
  color: #333;
  margin-bottom: 1rem;
}